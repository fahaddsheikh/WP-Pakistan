<?php

/*
 * AIT Shortcodes WordPress Plugin
 *
 * Copyright (c) 2013, Affinity Information Technology, s.r.o. (http://ait-themes.com)
 */


return array(

	'title' => __('Raw', 'ait-shortcodes'),

	'configuration' => array(
		'class' => 'AitRawShortcode',
		'type' => 'closed',
	),
);
